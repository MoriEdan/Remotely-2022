using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Remotely.Server.Pages
{
    public class AgentsModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}