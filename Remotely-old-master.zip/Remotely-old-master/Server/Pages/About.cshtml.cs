﻿using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Remotely.Server.Pages
{
    public class AboutModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
