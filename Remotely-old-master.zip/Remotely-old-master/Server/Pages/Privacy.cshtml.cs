﻿using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Remotely.Server.Pages
{
    public class PrivacyModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}