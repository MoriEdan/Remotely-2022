﻿using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Remotely.Server
{
    public class TwoFactorRequiredModel : PageModel
    {
        public void OnGet()
        {

        }
    }
}