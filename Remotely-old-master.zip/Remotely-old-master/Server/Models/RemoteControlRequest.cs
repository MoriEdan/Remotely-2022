﻿namespace Remotely.Server.Models
{
    public class RemoteControlRequest
    {
        public string DeviceID { get; set; }
        public string Email { get; set; }
        public string Password { get; set; }
    }
}
