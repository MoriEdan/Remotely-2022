# Installation
> `npm install --save @types/bootstrap`

# Summary
This package contains type definitions for Bootstrap (https://github.com/twbs/bootstrap/).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/bootstrap.

### Additional Details
 * Last updated: Wed, 20 May 2020 08:01:39 GMT
 * Dependencies: [@types/popper.js](https://npmjs.com/package/@types/popper.js), [@types/jquery](https://npmjs.com/package/@types/jquery)
 * Global values: `Bootstrap`

# Credits
These definitions were written by [denisname](https://github.com/denisname), and [Piotr Błażejewicz](https://github.com/peterblazejewicz).
