﻿export interface UserOptions {
    ID: string;
    ConsolePrompt: string;
    CommandModeShortcutWeb: string;
    CommandModeShortcutPSCore: string;
    CommandModeShortcutWinPS: string;
    CommandModeShortcutCMD: string;
    CommandModeShortcutBash: string;
}