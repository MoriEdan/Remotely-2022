﻿export class RemoteControlTarget {
    ServiceConnectionId: string;
    ViewOnlyMode: boolean;
}