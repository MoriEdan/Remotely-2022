﻿export enum RemoteControlMode {
    None,
    Unattended,
    Normal
}