﻿export const UserSettings = {
    PromptString: "~>",

    CommandModeShortcuts: {
        "Web": "/web",
        "PSCore": "/pscore",
        "WinPS": "/winps",
        "CMD": "/cmd",
        "Bash": "/bash"
    }
}