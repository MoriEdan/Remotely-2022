﻿import { BaseDtoType } from "../../Shared/Enums/BaseDtoType.js";

export interface BaseDto {
    DtoType: BaseDtoType;
}