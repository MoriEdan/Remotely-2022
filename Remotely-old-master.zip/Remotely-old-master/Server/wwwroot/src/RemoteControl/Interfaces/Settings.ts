﻿export interface Settings {
    autoQualityEnabled: boolean;
    qualityLevel: number;
    streamModeEnabled: boolean;
}