﻿namespace Remotely.Desktop.Core.Enums
{
    public enum AppMode
    {
        Unattended,
        Normal,
        Chat
    }
}
