﻿using System;

namespace Remotely.Desktop.Core
{
    public class ServiceContainer
    {
        public static IServiceProvider Instance { get; set; }
    }
}
