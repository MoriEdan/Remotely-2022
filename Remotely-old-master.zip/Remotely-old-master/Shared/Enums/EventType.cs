﻿namespace Remotely.Shared.Enums
{
    public enum EventType
    {
        Info = 0,
        Error = 1,
        Debug = 2,
        Warning = 3
    }
}
