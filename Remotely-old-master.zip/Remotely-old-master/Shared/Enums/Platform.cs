﻿namespace Remotely.Shared.Enums
{
    public enum Platform
    {
        Windows,
        Linux,
        OSX,
        Unknown
    }
}
