﻿namespace Remotely.Shared.Enums
{
    public enum Theme
    {
        Light,
        Dark
    }
}
