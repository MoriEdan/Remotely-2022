﻿namespace Remotely.Shared.Models
{
    public class PSError
    {
        public string Exception { get; set; }
        public string StackTrace { get; set; }

    }
}
