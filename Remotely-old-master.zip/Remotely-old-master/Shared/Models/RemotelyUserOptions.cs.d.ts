declare module server {
	interface remotelyUserOptions {
		consolePrompt: string;
		commandModeShortcutWeb: string;
		commandModeShortcutPSCore: string;
		commandModeShortcutWinPS: string;
		commandModeShortcutCMD: string;
		commandModeShortcutBash: string;
	}
}
